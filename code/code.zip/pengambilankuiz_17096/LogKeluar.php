<!--LogKeluar.php-->
<?php
	session_start();
	session_unset();
	header("location: Index.php");
?>
